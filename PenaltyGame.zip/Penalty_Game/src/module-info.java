module InterfazGrafica {
	requires java.desktop;
}